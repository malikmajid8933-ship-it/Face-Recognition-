# Face Recognition AI Project

A simple AI project that detects and recognizes known faces from images or a webcam using Python.

## Features
- Detects human faces using the `face_recognition` library.
- Compares detected faces with registered face images.
- Displays the recognized person's name or `Unknown`.
- Can be extended to use a webcam.

## Technologies
- Python
- face_recognition
- OpenCV
- NumPy

## Project Structure
```text
face-recognition-ai/
├── known_faces/
│   └── README.md
├── main.py
├── requirements.txt
├── .gitignore
└── README.md
```

## Installation

1. Install Python 3.9–3.11.
2. Install the dependencies:

```bash
pip install -r requirements.txt
```

3. Put clear photos of known people in `known_faces/`.
   Name each image with the person's name, for example:
   `Alice.jpg`
   `John.jpg`

4. Run:

```bash
python main.py
```

The program opens the default webcam and displays the recognized names.

## How the AI works

The system converts a face into numerical features called a face encoding. It compares the encoding of a detected face with the encodings of registered faces. If the distance is below the chosen tolerance, the face is considered a match; otherwise it is labeled `Unknown`.

## Responsible use

Use this project only with appropriate consent and for legitimate educational purposes. Face recognition involves biometric information, so avoid collecting or sharing people's face data without permission.

## Building AI connection

This project demonstrates:
- computer vision,
- classification by similarity,
- feature representations,
- distance-based matching,
- the practical use of AI for recognizing patterns in images.
