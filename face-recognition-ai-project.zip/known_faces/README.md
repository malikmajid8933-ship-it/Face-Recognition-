# Known Faces

Place consented reference photos here.

Example:
- `Alice.jpg`
- `John.jpg`

Do not upload private or sensitive face images to a public GitHub repository. For a public educational repository, keep this folder empty and use local images on your computer.
