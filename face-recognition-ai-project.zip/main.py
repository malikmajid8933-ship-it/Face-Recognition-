import os
import cv2
import face_recognition

KNOWN_DIR = "known_faces"
TOLERANCE = 0.50

known_encodings = []
known_names = []

for filename in os.listdir(KNOWN_DIR):
    path = os.path.join(KNOWN_DIR, filename)

    if not filename.lower().endswith((".jpg", ".jpeg", ".png")):
        continue

    image = face_recognition.load_image_file(path)
    encodings = face_recognition.face_encodings(image)

    if not encodings:
        print(f"No face found in {filename}; skipped.")
        continue

    known_encodings.append(encodings[0])
    known_names.append(os.path.splitext(filename)[0])

print("Known faces:", ", ".join(known_names) if known_names else "None")

camera = cv2.VideoCapture(0)

if not camera.isOpened():
    raise RuntimeError("Could not open the webcam.")

while True:
    ok, frame = camera.read()
    if not ok:
        break

    # Resize for faster processing.
    small = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
    rgb = cv2.cvtColor(small, cv2.COLOR_BGR2RGB)

    locations = face_recognition.face_locations(rgb)
    encodings = face_recognition.face_encodings(rgb, locations)

    for (top, right, bottom, left), encoding in zip(locations, encodings):
        name = "Unknown"

        if known_encodings:
            distances = face_recognition.face_distance(known_encodings, encoding)
            best_index = distances.argmin()

            if distances[best_index] <= TOLERANCE:
                name = known_names[best_index]

        # Scale coordinates back to the original frame.
        top *= 4
        right *= 4
        bottom *= 4
        left *= 4

        cv2.rectangle(frame, (left, top), (right, bottom), (255, 255, 255), 2)
        cv2.rectangle(frame, (left, bottom - 35), (right, bottom), (0, 0, 0), cv2.FILLED)
        cv2.putText(
            frame, name, (left + 6, bottom - 8),
            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2
        )

    cv2.imshow("Face Recognition AI", frame)

    # Press Q to quit.
    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

camera.release()
cv2.destroyAllWindows()
